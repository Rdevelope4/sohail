import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));

// Install React using `npx create-react-app my-crud-app`.
// Replace the contents of src/ with the code provided above.