import React, { useState } from 'react';
import { mockUsers } from './data/mockUsers';
import UserTable from './components/UserTable';
import UserForm from './components/UserForm';

const App = () => {
  const [users, setUsers] = useState(mockUsers);
  const [selectedUser, setSelectedUser] = useState(null);

  const handleSave = (user) => {
    if (user.id) {
      // Update existing user
      setUsers(users.map((u) => (u.id === user.id ? user : u)));
    } else {
      // Add new user
      user.id = users.length + 1;
      setUsers([...users, user]);
    }
    setSelectedUser(null);
  };

  const handleEdit = (user) => {
    setSelectedUser(user);
  };

  const handleDelete = (id) => {
    setUsers(users.filter((user) => user.id !== id));
  };

  return (
    <div>
      <h1>Simple CRUD App</h1>
      <UserForm selectedUser={selectedUser} onSave={handleSave} />
      <UserTable users={users} onEdit={handleEdit} onDelete={handleDelete} />
    </div>
  );
};

export default App;